const apiButton = document.getElementById('apiButton');
const apiData=document.getElementById('apiData')
const callApi= () => {
    fetch('https://jsonplaceholder.typicode.com/comments')
        .then(res => res.json())
        .then(data => {
            apiData.innerText = JSON.stringify(data);
        })
        .catch(e =>console.error(new Error(e)));

}
apiButton.addEventListener('click',callApi);